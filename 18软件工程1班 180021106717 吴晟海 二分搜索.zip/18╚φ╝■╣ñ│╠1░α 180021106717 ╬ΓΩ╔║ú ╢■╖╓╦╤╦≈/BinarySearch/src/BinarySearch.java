import java.util.Scanner;

public class BinarySearch {

	  // �ݹ���ֲ���
	  public static int binarySearch(int[] arr, int num, int low, int high) {
		  int mid = (low + high) / 2;   
	   
		  if (low > high) {		// �ݹ��������
	      return -1;
		  }
		  if (num < arr[mid]) {
			  return binarySearch(arr, num, low, mid - 1);
		  } 
		  else if (num == arr[mid]) {
			  return mid;
		  	} 
		  	else {
		  			return binarySearch(arr, num, mid + 1, high);
		  		}
	     
	  }
	  // �ǵݹ���ֲ���
	  public static int search(int[] arr, int num) {
	    int low = 0;
	    int high = arr.length - 1;
	    int mid = 0;
	    while (low <= high) {
	      mid = (low + high) / 2;
	      if (num < arr[mid]) {
	        high = mid - 1;
	      }
	       
	      if (num > arr[mid]) {
	        low = mid + 1;
	      }
	      if (num == arr[mid]) {
	        return mid;
	      }
	    }
	    return -1; //δ�ҵ�
	  }

	   
	   
public static void main(String[] args) {
	    
	    int[] arr = {2, 3, 5, 7, 8, 9, 11, 12, 15};//��С��������.
	    Scanner input = new Scanner(System.in);
	    System.out.print("Enter the number :");
		int number = input.nextInt();
	    int index = binarySearch(arr, number, 0, arr.length - 1); 
	    System.out.println(index); 
	  }

}
