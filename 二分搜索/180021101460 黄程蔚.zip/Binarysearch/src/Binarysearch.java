
public class Binarysearch {
	public static void main(String[] args){
		java.util.Scanner scan = new java.util.Scanner(System.in);
		int x = scan.nextInt();
		int b[]={1,3,5,7,9,11,13,15,17,19};
		if(search(b,x)==-1)
		System.out.println("δ�ҵ�x");
		else
			System.out.println("x������ĵ�"+search(b,x)+"λ");
	
	}
	
	static int search(int b[],int x){
		int n=b.length;
		int left=0; 
		int right=n;
		while(left<=right){
			int middle=(left+right)/2;
			if(x==b[middle])
				return middle+1;
			if(x>b[middle])
				left=middle+1;
			else
				right=middle-1;
		}
		return -1;
	}
}



	
